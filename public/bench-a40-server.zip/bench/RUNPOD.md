# Running chart 1 on RunPod

## 0. Before renting anything
- Push this repo (hf_server.py, loadgen.py, plot_throughput.py, requirements.txt) to GitHub.

## 1. Launch the pod
- GPU: A40 (48 GB). Template: a recent PyTorch template.
- Volume disk: ~50 GB (mounted at /workspace, survives stops).
- Open the web terminal (or SSH).

## 2. Setup (once per new volume)
```bash
cd /workspace
git clone <your repo url> bench && cd bench
pip install -r requirements.txt
export HF_HOME=/workspace/hf_cache
nvidia-smi
python -c "import vllm, torch, transformers; print(vllm.__version__, torch.__version__, transformers.__version__)"
```
Record the versions and the GPU memory total in your notes.

Use `tmux` so servers keep running if the browser tab disconnects:
```bash
tmux new -s srv      # Ctrl-b d to detach, `tmux attach -t srv` to come back
```

## 3. Smoke test first (cheap, catches bugs)
In tmux window 1:
```bash
vllm serve Qwen/Qwen2.5-7B-Instruct --max-num-batched-tokens 2048 --max-num-seqs 256 \
  --gpu-memory-utilization 0.9 2>&1 | tee vllm_startup.log
```
Wait for "Application startup complete". Save the log; read KV cache size, chunked prefill, prefix caching.

In tmux window 2:
```bash
python loadgen.py --engine vllm --url http://localhost:8000 --input-len 512 --output-len 128 \
  --concurrency 1 4 --num-requests 20 --out results/smoke_vllm
```
Check: no errors, wrong_output_len = 0, littles_law_inflight close to C, and no
"metric(s) not found" warning. If you get that warning, see what vLLM 0.30 calls them:
```bash
curl -s localhost:8000/metrics | grep -E "^vllm:num_(requests|preempt)"
```
and update the WANTED names near the top of loadgen.py.

Use a fresh `--out` folder for each real run (re-running into the same folder appends;
the plot keeps the latest row per concurrency, but per-level files get overwritten).

## 4. vLLM sweep A
```bash
python loadgen.py --engine vllm --url http://localhost:8000 --input-len 512 --output-len 128 \
  --concurrency 1 2 4 8 16 32 64 128 --num-requests 200 --out results/vllm_A
```
Then stop vLLM (Ctrl-C in window 1). Only one server on the GPU at a time.

## 5. HF sweep A
Window 1:
```bash
python hf_server.py --model Qwen/Qwen2.5-7B-Instruct --port 8001
```
Window 2. First time one request (call it t):
```bash
python loadgen.py --engine hf --url http://localhost:8001 --input-len 512 --output-len 128 \
  --concurrency 1 --num-requests 10 --out results/hf_timing
```
Then the full sweep, 1 → 128 (fewer measured requests, since HF is slow and its throughput is flat):
```bash
python loadgen.py --engine hf --url http://localhost:8001 --input-len 512 --output-len 128 \
  --concurrency 1 2 4 8 16 32 64 128 --num-requests 50 --out results/hf_A
```
Each level costs about (C + 50) × t because it needs C warmup completions, so the whole sweep is
about 655 × t (C = 128 alone is 178 × t). Example: if t ≈ 6 s, that's about 65 minutes.
If that's too long, run `--concurrency 1 2 4 8 16 32 64 128 --num-requests 30`, or stop at 64 and
note in the post where and why you stopped.

## 6. Plot
```bash
python plot_throughput.py --run results/vllm_A "vLLM in=512" --run results/hf_A "HF in=512" \
  --out chart1_A.png
```

## What to check in each printed summary line
- `errors` = 0 and `wrong_output_len` = 0. If not, don't trust that level.
- `littles_law_inflight` ≈ C. If it's well below C, requests aren't really overlapping (client bug or timeouts).
- vLLM: `running_mean` vs C. Below C with `waiting_mean` > 0 means a cap (KV memory or max-num-seqs) is binding.
- vLLM: `preemptions_in_window` > 0 means you hit the KV capacity wall.
- `throughput_tok_s` is end-to-end (chart 1). `decode_tok_s_est` (= running ÷ TPOT) is decode-only;
  plot it with `--metric decode_tok_s_est` to see the prefill gap.

## Rough time budget (sweep A)
- vLLM: 8 levels × ~200+ requests. Likely 10–20 minutes total.
- HF: the full 1 → 128 sweep is about 655 × (one request's time) at 50 measured requests per level.
  Time one request first and check the total against your budget.

## 7. Save results and STOP the pod
```bash
git add results/ *.png vllm_startup.log && git commit -m "sweep A results" && git push
```
Then stop the pod in the RunPod console. Billing continues until you do.
