"""Chart 1: throughput vs concurrency.

Usage:
  python plot_throughput.py --run results/vllm_A "vLLM, in=512" \
                            --run results/hf_A "HF, in=512" \
                            --predictions predictions.csv --out chart1.png

predictions.csv (optional), columns: label,concurrency,throughput_tok_s
Predicted lines are drawn dashed, in the same color as the matching run label.
"""

import argparse
import csv
import json
import os
from collections import defaultdict

import matplotlib.pyplot as plt


def load_summary(run_dir):
    # If a folder was run more than once, keep only the latest row per concurrency.
    latest = {}
    for l in open(os.path.join(run_dir, "summary.jsonl")):
        if l.strip():
            r = json.loads(l)
            latest[r["concurrency"]] = r
    return [latest[c] for c in sorted(latest)]


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--run", nargs=2, action="append", metavar=("DIR", "LABEL"), required=True)
    p.add_argument("--predictions")
    p.add_argument("--metric", default="throughput_tok_s",
                   help="summary field for y (e.g. decode_tok_s_est)")
    p.add_argument("--out", default="chart1.png")
    args = p.parse_args()

    preds = defaultdict(list)
    if args.predictions:
        for row in csv.DictReader(open(args.predictions)):
            if not (row.get("throughput_tok_s") or "").strip():
                continue  # unfilled prediction
            preds[row["label"]].append((int(row["concurrency"]), float(row["throughput_tok_s"])))

    fig, ax = plt.subplots(figsize=(7, 4.5))
    for run_dir, label in args.run:
        rows = load_summary(run_dir)
        pts = [(r["concurrency"], r.get(args.metric)) for r in rows if r.get(args.metric) is not None]
        if not pts:
            print(f"skipping {label}: no '{args.metric}' values")
            continue
        xs, ys = zip(*pts)
        line, = ax.plot(xs, ys, "o-", label=f"{label} (measured)")
        if label in preds:
            px, py = zip(*sorted(preds[label]))
            ax.plot(px, py, "--", color=line.get_color(), alpha=0.8, label=f"{label} (predicted)")

    ax.set_xscale("log", base=2)
    ax.set_xlabel("Concurrency (requests in flight)")
    ax.set_ylabel("Output tokens / s" if args.metric == "throughput_tok_s" else args.metric)
    ax.set_title("Throughput vs concurrency (closed loop)")
    ax.grid(True, which="both", alpha=0.3)
    ax.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(args.out, dpi=150)
    print(f"saved {args.out}")


if __name__ == "__main__":
    main()
