"""Naive HF baseline server: one request at a time, no batching.

POST /generate  {"input_ids": [...], "max_new_tokens": N}
  -> server-sent events: one {"n": k} event per generated token step,
     then {"done": true, "completion_tokens": total}
GET  /busy      -> {"busy": bool}   (load generator waits for idle between levels)

Run:  python hf_server.py --model Qwen/Qwen2.5-7B-Instruct --port 8001
"""

import argparse
import asyncio
import json
import threading
import time

import torch
import uvicorn
from fastapi import FastAPI
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from transformers import AutoModelForCausalLM
from transformers.generation.streamers import BaseStreamer

app = FastAPI()
gpu_lock = asyncio.Lock()  # the "one request at a time" rule
model = None
pad_id = None
active_generations = 0      # generate() threads still running (they outlive cancelled requests)
active_lock = threading.Lock()


class GenerateRequest(BaseModel):
    input_ids: list[int]
    max_new_tokens: int


class TokenQueueStreamer(BaseStreamer):
    """Pushes one event per generated token into an asyncio queue."""

    def __init__(self, loop, queue):
        self.loop = loop
        self.queue = queue
        self.seen_prompt = False

    def put(self, value):
        # generate() first calls put() with the prompt; skip it.
        if not self.seen_prompt:
            self.seen_prompt = True
            return
        n = value.reshape(-1).numel()
        self.loop.call_soon_threadsafe(self.queue.put_nowait, ("tok", n))

    def end(self):
        self.loop.call_soon_threadsafe(self.queue.put_nowait, ("end", 0))


@app.get("/busy")
async def busy():
    return {"busy": gpu_lock.locked() or active_generations > 0}


@app.post("/generate")
async def generate(req: GenerateRequest):
    async def stream():
        async with gpu_lock:
            loop = asyncio.get_running_loop()
            queue: asyncio.Queue = asyncio.Queue()
            streamer = TokenQueueStreamer(loop, queue)

            def run():
                global active_generations
                with active_lock:
                    active_generations += 1
                try:
                    with torch.inference_mode():
                        ids = torch.tensor([req.input_ids], device="cuda")
                        model.generate(
                            ids,
                            attention_mask=torch.ones_like(ids),
                            max_new_tokens=req.max_new_tokens,
                            min_new_tokens=req.max_new_tokens,  # force exact length
                            do_sample=False,                      # greedy
                            pad_token_id=pad_id,
                            streamer=streamer,
                        )
                except Exception as e:  # surface errors to the client
                    loop.call_soon_threadsafe(queue.put_nowait, ("err", str(e)))
                finally:
                    with active_lock:
                        active_generations -= 1

            thread = threading.Thread(target=run, daemon=True)
            thread.start()

            total = 0
            while True:
                kind, val = await queue.get()
                if kind == "tok":
                    total += val
                    yield f"data: {json.dumps({'n': val})}\n\n"
                elif kind == "end":
                    break
                else:
                    yield f"data: {json.dumps({'error': val})}\n\n"
                    break
            await loop.run_in_executor(None, thread.join)
            yield f"data: {json.dumps({'done': True, 'completion_tokens': total})}\n\n"

    return StreamingResponse(stream(), media_type="text/event-stream")


def main():
    global model, pad_id
    p = argparse.ArgumentParser()
    p.add_argument("--model", default="Qwen/Qwen2.5-7B-Instruct")
    p.add_argument("--port", type=int, default=8001)
    args = p.parse_args()

    model = AutoModelForCausalLM.from_pretrained(
        args.model,
        torch_dtype=torch.bfloat16,
        attn_implementation="sdpa",  # keep transformers' own fast attention ON
    ).to("cuda")
    model.eval()
    gc = model.generation_config
    gc.temperature = gc.top_p = gc.top_k = None  # silence greedy-mode warnings
    eos = gc.eos_token_id
    pad_id = gc.pad_token_id if gc.pad_token_id is not None else (
        eos[0] if isinstance(eos, list) else eos
    )
    print(f"Loaded {args.model}; torch {torch.__version__}")
    uvicorn.run(app, host="0.0.0.0", port=args.port, log_level="warning")


if __name__ == "__main__":
    main()
