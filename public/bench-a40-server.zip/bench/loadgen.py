"""Closed-loop load generator for the HF baseline and vLLM.

For each concurrency C: C clients each loop "send request -> wait for full
streamed response -> send next". Each client starts after a small random delay
(jitter) so requests don't run in lockstep. The first W completions are
discarded as warmup (W >= C); throughput is measured over the window between
completion W and completion W + N, so ramp-up and tail are both excluded.

Examples:
  # vLLM (server already running on :8000)
  python loadgen.py --engine vllm --url http://localhost:8000 \
      --model Qwen/Qwen2.5-7B-Instruct --input-len 512 --output-len 128 \
      --concurrency 1 2 4 8 16 32 64 128 --out results/vllm_A

  # HF baseline (hf_server.py running on :8001)
  python loadgen.py --engine hf --url http://localhost:8001 \
      --input-len 512 --output-len 128 --concurrency 1 2 4 8 16 \
      --num-requests 60 --out results/hf_A
"""

import argparse
import asyncio
import json
import os
import random
import re
import statistics
import time

import aiohttp

# Random token IDs from the normal vocab range (Qwen2.5 special tokens start at 151643).
TOKEN_LOW, TOKEN_HIGH = 1000, 150000


def make_prompt(rng: random.Random, n: int) -> list[int]:
    # Random from the very first token, so prefix caching can't share anything.
    return [rng.randint(TOKEN_LOW, TOKEN_HIGH) for _ in range(n)]


async def sse_events(resp):
    """Yield (timestamp, payload_dict_or_None_for_DONE) for each SSE data line."""
    buf = b""
    async for chunk in resp.content.iter_any():
        t = time.perf_counter()
        buf += chunk
        while b"\n" in buf:
            line, buf = buf.split(b"\n", 1)
            line = line.strip()
            if not line.startswith(b"data:"):
                continue
            data = line[5:].strip()
            if data == b"[DONE]":
                yield t, None
            else:
                yield t, json.loads(data)


async def send_vllm(session, args, prompt):
    payload = {
        "model": args.model,
        "prompt": prompt,                 # token IDs, so input length is exact
        "max_tokens": args.output_len,
        "ignore_eos": True,               # force exact output length
        "temperature": 0,
        "stream": True,
        "stream_options": {"include_usage": True},
    }
    rec = {"start": time.perf_counter(), "ttft": None, "tokens": None, "error": None}
    try:
        async with session.post(f"{args.url}/v1/completions", json=payload) as resp:
            if resp.status != 200:
                rec["error"] = f"HTTP {resp.status}: {(await resp.text())[:200]}"
                return rec
            async for t, ev in sse_events(resp):
                if ev is None:
                    break
                if ev.get("choices") and rec["ttft"] is None:
                    rec["ttft"] = t - rec["start"]
                if ev.get("usage"):
                    rec["tokens"] = ev["usage"]["completion_tokens"]
    except Exception as e:
        rec["error"] = repr(e)
    rec["end"] = time.perf_counter()
    return rec


async def send_hf(session, args, prompt):
    payload = {"input_ids": prompt, "max_new_tokens": args.output_len}
    rec = {"start": time.perf_counter(), "ttft": None, "tokens": None, "error": None}
    try:
        async with session.post(f"{args.url}/generate", json=payload) as resp:
            if resp.status != 200:
                rec["error"] = f"HTTP {resp.status}: {(await resp.text())[:200]}"
                return rec
            async for t, ev in sse_events(resp):
                if ev is None:
                    break
                if "n" in ev and rec["ttft"] is None:
                    rec["ttft"] = t - rec["start"]
                if "error" in ev:
                    rec["error"] = ev["error"]
                if ev.get("done"):
                    rec["tokens"] = ev["completion_tokens"]
                    break
    except Exception as e:
        rec["error"] = repr(e)
    rec["end"] = time.perf_counter()
    return rec


METRIC_RE = re.compile(r"^(vllm:[a-z_]+)(?:\{[^}]*\})?\s+([0-9.eE+-]+)$")
WANTED = ("vllm:num_requests_running", "vllm:num_requests_waiting",
          "vllm:num_preemptions_total")


async def poll_metrics(session, url, samples, stop):
    """Poll vLLM's /metrics: running/waiting counts and preemptions."""
    while not stop.is_set():
        try:
            async with session.get(f"{url}/metrics") as r:
                text = await r.text()
            vals = {k: None for k in WANTED}  # None = metric name not found (don't fake a 0)
            for line in text.splitlines():
                m = METRIC_RE.match(line)
                if m and m.group(1) in vals:
                    vals[m.group(1)] = (vals[m.group(1)] or 0.0) + float(m.group(2))
            samples.append({"t": time.perf_counter(), **vals})
        except Exception:
            pass
        try:
            await asyncio.wait_for(stop.wait(), timeout=0.5)
        except asyncio.TimeoutError:
            pass


async def wait_hf_idle(session, url):
    """Cancelled HF requests keep generating server-side; wait for them."""
    while True:
        try:
            async with session.get(f"{url}/busy") as r:
                if not (await r.json())["busy"]:
                    return
        except Exception:
            pass
        await asyncio.sleep(1)


def pct(xs, q):
    xs = sorted(xs)
    if not xs:
        return None
    k = (len(xs) - 1) * q
    lo, hi = int(k), min(int(k) + 1, len(xs) - 1)
    return xs[lo] + (xs[hi] - xs[lo]) * (k - lo)


async def run_level(session, args, C, send, rng):
    warmup = max(C, args.warmup)
    target = warmup + args.num_requests
    completed = []
    stop = asyncio.Event()

    async def client():
        await asyncio.sleep(rng.uniform(0, args.jitter))
        while not stop.is_set():
            rec = await send(session, args, make_prompt(rng, args.input_len))
            completed.append(rec)
            if len(completed) >= target:
                stop.set()

    samples, mstop = [], asyncio.Event()
    poller = (asyncio.create_task(poll_metrics(session, args.url, samples, mstop))
              if args.engine == "vllm" else None)

    tasks = [asyncio.create_task(client()) for _ in range(C)]
    await stop.wait()
    for t in tasks:
        t.cancel()
    await asyncio.gather(*tasks, return_exceptions=True)
    mstop.set()
    if poller:
        await poller
    if args.engine == "hf":
        await wait_hf_idle(session, args.url)

    window = completed[warmup:target]
    t0, t1 = completed[warmup - 1]["end"], completed[target - 1]["end"]
    ok = [r for r in window if r["error"] is None and r["tokens"]]
    for r in ok:
        r["e2e"] = r["end"] - r["start"]
        r["tpot"] = (r["e2e"] - r["ttft"]) / max(r["tokens"] - 1, 1)

    wrong_len = sum(1 for r in ok if r["tokens"] != args.output_len)
    out_tokens = sum(r["tokens"] for r in ok)
    duration = t1 - t0
    m_window = [s for s in samples if t0 <= s["t"] <= t1]

    summary = {
        "engine": args.engine, "concurrency": C,
        "input_len": args.input_len, "output_len": args.output_len,
        "measured_requests": len(window), "errors": len(window) - len(ok),
        "wrong_output_len": wrong_len,
        "duration_s": duration,
        "throughput_tok_s": out_tokens / duration,          # end-to-end
        "throughput_req_s": len(ok) / duration,
        "ttft_p50": pct([r["ttft"] for r in ok], .5), "ttft_p99": pct([r["ttft"] for r in ok], .99),
        "tpot_p50": pct([r["tpot"] for r in ok], .5), "tpot_p99": pct([r["tpot"] for r in ok], .99),
        "e2e_p50": pct([r["e2e"] for r in ok], .5), "e2e_p99": pct([r["e2e"] for r in ok], .99),
        "e2e_mean": statistics.mean(r["e2e"] for r in ok) if ok else None,
        "tpot_mean": statistics.mean(r["tpot"] for r in ok) if ok else None,
    }
    # Decode-only throughput: excludes TTFT (queueing + prefill) because TPOT does.
    # = (sequences decoding at once) / (mean seconds per token per sequence).
    # HF decodes exactly one sequence at a time, so it's 1 / TPOT.
    if ok and args.engine == "hf":
        summary["decode_tok_s_est"] = 1.0 / summary["tpot_mean"]
    # Little's law check: in-flight ~= request throughput x mean latency (should be ~C)
    if ok:
        summary["littles_law_inflight"] = summary["throughput_req_s"] * summary["e2e_mean"]
    if args.engine == "vllm" and not m_window:
        print("WARNING: no /metrics samples in the measured window", flush=True)
    if m_window:
        missing = [k for k in WANTED if m_window[0][k] is None]
        if missing:
            print(f"WARNING: metric(s) not found in /metrics (name changed?): {missing}. "
                  f"Check `curl localhost:8000/metrics | grep vllm:`", flush=True)
        if m_window[0]["vllm:num_requests_running"] is not None:
            summary["running_mean"] = statistics.mean(s["vllm:num_requests_running"] for s in m_window)
            # vLLM: running count also includes requests still in prefill, so this slightly
            # overestimates decode throughput when prefills are frequent (e.g. 8192-token inputs).
            if summary.get("tpot_mean"):
                summary["decode_tok_s_est"] = summary["running_mean"] / summary["tpot_mean"]
        if m_window[0]["vllm:num_requests_waiting"] is not None:
            summary["waiting_mean"] = statistics.mean(s["vllm:num_requests_waiting"] for s in m_window)
        if m_window[0]["vllm:num_preemptions_total"] is not None:
            summary["preemptions_in_window"] = (m_window[-1]["vllm:num_preemptions_total"]
                                                - m_window[0]["vllm:num_preemptions_total"])
    return summary, window, samples


async def main():
    p = argparse.ArgumentParser()
    p.add_argument("--engine", choices=["vllm", "hf"], required=True)
    p.add_argument("--url", required=True)
    p.add_argument("--model", default="Qwen/Qwen2.5-7B-Instruct")
    p.add_argument("--input-len", type=int, required=True)
    p.add_argument("--output-len", type=int, required=True)
    p.add_argument("--concurrency", type=int, nargs="+", required=True)
    p.add_argument("--num-requests", type=int, default=200, help="measured completions per level")
    p.add_argument("--warmup", type=int, default=10, help="min warmup completions (actual = max(C, this))")
    p.add_argument("--global-warmup", type=int, default=5, help="requests at C=1 before the sweep, discarded")
    p.add_argument("--jitter", type=float, default=1.0, help="max random start delay per client (s)")
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--out", required=True)
    args = p.parse_args()

    os.makedirs(args.out, exist_ok=True)
    rng = random.Random(args.seed)
    send = send_vllm if args.engine == "vllm" else send_hf
    timeout = aiohttp.ClientTimeout(total=None, sock_read=None, sock_connect=60)
    connector = aiohttp.TCPConnector(limit=0)  # no client-side connection cap

    async with aiohttp.ClientSession(timeout=timeout, connector=connector) as session:
        print(f"global warmup: {args.global_warmup} requests")
        for _ in range(args.global_warmup):
            await send(session, args, make_prompt(rng, args.input_len))

        for C in args.concurrency:
            print(f"--- concurrency {C} ---", flush=True)
            summary, window, samples = await run_level(session, args, C, send, rng)
            with open(os.path.join(args.out, f"c{C}.json"), "w") as f:
                json.dump({"summary": summary, "requests": window, "metrics": samples}, f)
            with open(os.path.join(args.out, "summary.jsonl"), "a") as f:
                f.write(json.dumps(summary) + "\n")
            print(json.dumps({k: (round(v, 4) if isinstance(v, float) else v)
                              for k, v in summary.items()}), flush=True)
            if summary["errors"] or summary["wrong_output_len"]:
                print("WARNING: errors or wrong output lengths at this level", flush=True)


if __name__ == "__main__":
    asyncio.run(main())
