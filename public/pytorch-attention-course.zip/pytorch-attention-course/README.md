# PyTorch to Attention (Hands-on Notebook)

This project contains a deliberate-practice notebook:

- `pytorch_to_attention.ipynb`

The notebook is designed to make **you write the important code** (instead of reading pre-solved code) so you can deeply understand tensor shapes, `nn.Module`, autograd, optimization, and Transformer-style attention.

## Requirements

- Python 3.10+
- PyTorch
- Jupyter Notebook / JupyterLab
- Matplotlib (used only in a few visualization cells)

Install dependencies (example):

```bash
pip install torch jupyter matplotlib
```

## Run

```bash
jupyter notebook pytorch_to_attention.ipynb
```

## How to use the notebook effectively

1. Attempt every `TODO` yourself before viewing any solution cell.
2. Predict tensor shapes before executing cells.
3. Use tests/assertions to validate your code.
4. Use debugging exercises to practice diagnosing shape and training mistakes.
5. Treat this as deliberate practice, not passive reading.

## Notes

- Solutions are provided in separate cells so you can skip them initially.
- The final project intentionally does **not** include a full solution.
